/*
 * JSONLikes.h
 *
 *  Created on: Mar 25, 2024
 *      Author: erkan
 */

#ifndef JSONLIKES_H_
#define JSONLIKES_H_

enum class JValueType
{
   Str = 0,
   Num = 1,
   Dict = 32,
   Arr = 33
};


class JValue
{
      JValueType type;
   public:
      JValue(JValueType t);
      JValueType getType();
      virtual void report(ofstream *os)=0;
      virtual ~JValue();
};

class JValueDouble : public JValue
{
   private:
      double   val;
   public:
      JValueDouble(double d);
      virtual void report(ofstream *os);
};

class JValueStr : public JValue
{
   private:
      string *str;
   public:
      JValueStr(string *s);
      virtual ~JValueStr();
      virtual void report(ofstream *os);
};

class JMember
{
   private:
      string     *id;
      JValue     *value;
   public:
      JMember(string *pId, JValue *pValue);
      virtual ~JMember();
      virtual void report(ofstream *os);
};

class JDictionary : public JValue
{
   std::vector<JMember *>  *arr;

   public:
      JDictionary();
      ~JDictionary();

      void addMember(JMember *m);
      virtual void report(ofstream *os);
};

class JArray : public JValue
{
   private:
      std::vector<JValue *>  *arr;
   public:
      JArray();
      ~JArray();

      void addElement(JValue *v);
      virtual void report(ofstream *os);
};

#endif /* JSONLIKES_H_ */
