using namespace std;

#include <iostream>
#include <fstream>
#include <string.h>
#include "sample03.tab.hh"
#include "MyParser.h"
#include "FlexLexer.h"
#include "MyFlexLexer.h"

MyParser::MyParser()
{
   lval=nullptr;
   parseError=false;
   valueType=JValueType::Num;
   latestValue=nullptr;
   base=nullptr;
   lexer=nullptr;
}

MyParser::~MyParser()
{
   if (latestValue!=nullptr)
      delete latestValue;

   delete lexer;
   delete base;
}

int MyParser::lex(yy::MyParserBase::semantic_type *const lval)
{
   this->lval=lval;
   return lexer->lex(lval);
}

void MyParser::parse(yy::MyParserBase *base, ifstream *is)
{
   this->base=base;
   lexer=new MyFlexLexer(this);
   lexer->switch_streams(is);
   base->parse();
}

int MyParser::getId()
{
   lval->STR=new string(lexer->YYText());
   return yy::MyParserBase::token::ID;
}

int MyParser::hexDigit(char c)
{
   if (c>='0' && c<='9')
      return c-'0';

   if (c>='A' && c<='F')
      return c-'A'+10;

   if (c>='a' && c<='f')
      return c-'a'+10;

   return -1;
}

string *MyParser::makeString(const char *rawStr)
{
   char *copyStr=strdup(rawStr),
        *p,
        *q;
   int   d;
   unsigned char c;

   q=copyStr;
   for (p=q+1;*p!='"';p++,q++)
   {
      switch (*p)
      {
         case '\\':
            p++;
            switch (*p)
            {
               case '\\':
                  *q='\\';
                  break;
               case 't':
                  *q='\t';
                  break;
               case 'r':
                  *q='\r';
                  break;
               case 'n':
                  *q='\n';
                  break;
               case '"':
                  *q='"';
                  break;
               case 'x':
                  p++;
                  c=(unsigned char)hexDigit(*p);
                  d=hexDigit(p[1]);
                  if (d>-1)
                  {
                     p++;
                     c=(c<<4) | (unsigned char)d;
                  }
                  *q=c;
            }
            break;
         default:
            *q=*p;

      }
   }
   *q=0;
   string *retVal=new string(copyStr);

   free(copyStr);

   return retVal;
}

int MyParser::getStr()
{
   lval->STR=makeString(lexer->YYText());
   return yy::MyParserBase::token::STR;
}

int MyParser::getNumber()
{
   lval->NUM=atof(lexer->YYText());
   return yy::MyParserBase::token::NUM;
}

JValue *MyParser::setValue(string *strVal)
{
   latestValue=new JValueStr(strVal);
   return latestValue;
}

JValue *MyParser::setValue(double doubleVal)
{
   latestValue=new JValueDouble(doubleVal);
   return latestValue;
}

JValue *MyParser::setValue(JDictionary *dictionary)
{
   latestValue=dictionary;
   return latestValue;
}

JValue *MyParser::setValue(JArray *array)
{
   latestValue=array;
   return latestValue;
}

JMember *MyParser::createMember(string *name, JValue *value)
{
   return new JMember(name, value);
}

JDictionary *MyParser::storeMember(JMember *member)
{
   JDictionary *dictionary=new JDictionary();

   dictionary->addMember(member);

   return dictionary;

}

JDictionary *MyParser::storeMember(JMember *member, JDictionary *dictionary)
{
   dictionary->addMember(member);

   return dictionary;

}

JArray *MyParser::storeArrElement(JValue *value)
{
   JArray *array=new JArray();

   array->addElement(value);

   return array;
}

JArray *MyParser::storeArrElement(JValue *value, JArray * array)
{
   array->addElement(value);

   return array;
}

void MyParser::setParseError()
{
   parseError=true;
}

bool MyParser::getParseError()
{
   return parseError;
}

void MyParser::reportValue()
{
   if (latestValue!=nullptr)
   {
      ofstream *os=new ofstream("sample03out.txt");

      latestValue->report(os);

      os->close();
   }
}

void yy::MyParserBase::error(const std::string &msg)
{
   driver->setParseError();
}
