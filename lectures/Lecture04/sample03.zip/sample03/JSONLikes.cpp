using namespace std;

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include "JSONLikes.h"

JValue::JValue(JValueType t)
{
   type=t;
}

JValueType JValue::getType()
{
   return type;
}

JValue::~JValue()
{
}

JValueDouble::JValueDouble(double d)
   :JValue(JValueType::Num)
{
   val=d;
}

void JValueDouble::report(ofstream *os)
{
   (*os) << val;
}

JValueStr::JValueStr(string *s)
   :JValue(JValueType::Str)
{
   str=s;
}

JValueStr::~JValueStr()
{
   delete str;
}

void JValueStr::report(ofstream *os)
{
   static  unsigned char const *hd=(unsigned char const *)"0123456789abcdef";
   string  t=string();
   int     l=(int)str->length();

   t+='"';
   for (int i=0;i<l;i++)
   {
      char c=(*str)[i];

      switch (c)
      {
         case '\n':
            t+="\\n";
            break;
         case '\t':
            t+="\\t";
            break;
         case '\r':
            t+="\\r";
            break;
         case '\\':
            t+="\\\\";
            break;
         default:
            if (c<32)
            {
               t+="\\x";
               t+=hd[c>>4];
               t+=hd[c&0xf];
            }
            else
               t+=(*str)[i];
      }
   }

   t+='"';
   (*os) << t;
}

JMember::JMember(string *pId, JValue *pValue)
{
   id=pId;
   value=pValue;
}

JMember::~JMember()
{
   delete id;
   delete value;
}

void JMember::report(ofstream *os)
{
   (*os) << "\"" << id->c_str() << "\": ";
   value->report(os);
}

JDictionary::JDictionary()
   :JValue(JValueType::Dict)
{
   arr=new std::vector<JMember *>();
}

JDictionary::~JDictionary()
{
   for (std::vector<JMember *>::size_type i=0;i!=arr->size();i++)
      delete (*arr)[i];
}

void JDictionary::addMember(JMember *m)
{
   arr->push_back(m);
}

void JDictionary::report(ofstream *os)
{
   (*os) << "{";

   int i=(int)arr->size()-1;

   if (i>=0)
   {
      (*arr)[i]->report(os);
      for (i--;i>-1;i--)
      {
         (*os) << ", ";
         (*arr)[i]->report(os);
      }
   }
   (*os) << "}";
}

JArray::JArray()
   :JValue(JValueType::Arr)
{
   arr=new std::vector<JValue *>();
}

JArray::~JArray()
{
   for (std::vector<JValue *>::size_type i=0;i!=arr->size();i++)
      delete (*arr)[i];
}

void JArray::addElement(JValue *v)
{
   arr->push_back(v);
}

void JArray::report(ofstream *os)
{
   (*os) << "[";

   int i=(int)arr->size()-1;

   if (i>=0)
   {
      (*arr)[i]->report(os);
      for (i--;i>-1;i--)
      {
         (*os) << ", ";
         (*arr)[i]->report(os);
      }
   }

   (*os) << "]";
}
