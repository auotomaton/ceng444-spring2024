/*
 * MyParser.h
 *
 *  Created on: Mar 24, 2024
 *      Author: erkan
 */

#ifndef MYPARSER_H_
#define MYPARSER_H_

namespace yy
{
   class MyParserBase;
};

#include "JSONLikes.h"

class MyFlexLexer;

class MyParser
{
   yy::MyParserBase *base;
   MyFlexLexer      *lexer;

   // Variable to integrate token semantics
   yy::MyParserBase::semantic_type *lval;

   bool              parseError;
   JValueType        valueType;
   JValue           *latestValue;

   string *makeString(const char *rawStr);
   int hexDigit(char c);
public:
   MyParser();
   ~MyParser();

   void parse(yy::MyParserBase *base, ifstream *is);
   int lex(yy::MyParserBase::value_type *lval);

   JValue *setValue(string *strVal);
   JValue *setValue(double doubleVal);
   JValue *setValue(JDictionary *dictionary);
   JValue *setValue(JArray *array);

   JMember *createMember(string *name, JValue *value);
   JDictionary *storeMember(JMember *member);
   JDictionary *storeMember(JMember *member, JDictionary *dictionary);

   JArray *storeArrElement(JValue *value);
   JArray *storeArrElement(JValue *value, JArray *array);

   int getId();
   int getStr();
   int getNumber();

   void setParseError();
   bool getParseError();

   void reportValue();
};


#endif /* MYPARSER_H_ */
