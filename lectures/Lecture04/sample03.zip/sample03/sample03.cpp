using namespace std;

#include <iostream>
#include <fstream>
#include "sample03.tab.hh"
#include "MyParser.h"
#include "FlexLexer.h"
#include "MyFlexLexer.h"

int main(int argc, char **argv)
{
   ifstream is("sample03.txt");

   if (is.is_open())
   {
      MyParser *driver=new MyParser();
      yy::MyParserBase *base=new yy::MyParserBase(driver);

      driver->parse(base, &is);

      is.close();

      if (driver->getParseError())
         cout << "Not recognized!" << endl;
      else
      {
         cout << "Recognized!" << endl;
         driver->reportValue();
      }
      delete driver;
   }
   return 0;
}
