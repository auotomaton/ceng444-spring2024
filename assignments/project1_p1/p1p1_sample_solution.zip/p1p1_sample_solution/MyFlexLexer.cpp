using namespace std;
#include <iostream>
#include <fstream>
#include <math.h>
#include "FlexLexer.h"
#include "MyFlexLexer.h"

MyFlexLexer::MyFlexLexer()
{
   resetProcessingParameters();
}

void MyFlexLexer::resetProcessingParameters()
{
   lineCount=1;
   ipv4Params=0;
   identifierCount=0;

   resetLineProcessingParameters();
   resetNumberSequenceProcessing();

   exceptionsStream=new ofstream("exceptions.txt");
   netTestsStream=new ofstream("nettests.txt");
   sequencesStream=new ofstream("sequences.txt");
   identifiersStream=new ofstream("identifiers.txt");
}

void MyFlexLexer::finalizeProcessing()
{
   processLineData();
   reportNumberSequence();
   (*identifiersStream) << "The number of the identifiers detected is " << identifierCount << endl;
   exceptionsStream->close();
   netTestsStream->close();
   sequencesStream->close();
   identifiersStream->close();
   lineCount--;
}

void MyFlexLexer::resetLineProcessingParameters()
{
   tokensInLine=0;
   errInLine=0;
}

void MyFlexLexer::resetNumberSequenceProcessing()
{
   sx=
   sx2=
   n=
   ltc=
   gtc=0;
}

void MyFlexLexer::reportExceptionLine(const char *msg)
{
   errInLine++;
   (*exceptionsStream) << "" << lineCount << ": " << msg << endl;
}

void MyFlexLexer::registerTokenInLine(int tokenId)
{
   if (tokensInLine<MAXTOKENINLINE)
      lineTokenBag[tokensInLine]=tokenId;

   tokensInLine++;
}

void MyFlexLexer::processLineData()
{
   if (tokensInLine>0)
   {
      if (errInLine==0)
         switch (lineTokenBag[0])
         {
            case TOKEN_NUMBER:
               if (tokensInLine==1)
               {
                  sx+=latestNumber;
                  sx2+=latestNumber*latestNumber;
                  if (n>0)
                  {
                     if (latestNumber<=latestElement)
                        ltc++;

                     if (latestNumber>=latestElement)
                        gtc++;

                     if (latestNumber>maximum)
                        maximum=latestNumber;
                     else
                        if (latestNumber<minimum)
                           minimum=latestNumber;
                  }
                  else
                     minimum=
                     maximum=latestNumber;

                  n++;
                  latestElement=latestNumber;
               }
               else
                  reportExceptionLine("Extra input on line.");
               break;
            case TOKEN_MASK:
               if (tokensInLine==2 && lineTokenBag[1]==TOKEN_IPV4)
                  setupMask();
               else
                  reportExceptionLine("Line does not conform to syntax: mask <IPV4>");
               break;
            case TOKEN_GATEWAY:
               if (tokensInLine==2 && lineTokenBag[1]==TOKEN_IPV4)
                  setupGateway();
               else
                  reportExceptionLine("Line does not conform to syntax: gateway <IPV4>");
               break;
            case TOKEN_ADDRESS:
               if (tokensInLine==2 && lineTokenBag[1]==TOKEN_IPV4)
                  performAddress();
               else
                  reportExceptionLine("Line does not conform to syntax: address <IPV4>");
               break;
            case TOKEN_RESET:
               if (tokensInLine==1)
               {
                  reportNumberSequence();
                  resetNumberSequenceProcessing();
               }
               else
                  reportExceptionLine("Extra input on line.");
               break;
            case TOKEN_IDENTIFIER:
               if (tokensInLine==1)
               {
                  identifierCount++;
               }
               else
                  reportExceptionLine("Extra input on line.");
               break;
            default:
               reportExceptionLine("Invalid line syntax.");

         }
   }
   lineCount++;
   resetLineProcessingParameters();
}

void MyFlexLexer::reportNumberSequence()
{
   sn++;
   (*sequencesStream) << "Sequence Number: " << sn << endl;

   if (n==0)
   {
      (*sequencesStream) << "Empty!" << endl;
   }
   else
   {
      double m=sx / n;

      (*sequencesStream) << "Minimum: " << minimum << endl
                         << "Maximum: " << maximum << endl
                         << "Number of entries: " << n << endl
                         << "Average: " << m << endl
                         << "Standard Deviation: " << sqrt(sx2/n - m*m) << endl
                         << "Is monotonic: " <<
                         ((n==1 || (gtc==n-1 && ltc==n-1))?"Yes":((n>1 && gtc==(n-1)) ?"Yes, increasing":((n>1 && ltc==(n-1)) ? "Yes decreasing":"No")))
                         << endl;
   }

   (*sequencesStream) << endl;
}

void MyFlexLexer::alertUnrecognized()
{
   reportExceptionLine("Unrecognized token.");
}

void MyFlexLexer::processNumber(const char *numberLexeme)
{
   latestNumber=atof(numberLexeme);
   registerTokenInLine(TOKEN_NUMBER);
}

void MyFlexLexer::processIPV4Adress(const char *ipv4Lexeme)
{
   int      sl=24,
            b=0;
   IPV4     addr=0;
   bool     overflow=false;

   for (const char *p=ipv4Lexeme;!overflow && *p;p++)
   {
      if (*p=='.')
      {
         addr|=b<<sl;
         sl-=8;
         b=0;
      }
      else
      {
         b=b*10+*p-'0';
         overflow=(b>255);
      }
   }
   registerTokenInLine(TOKEN_IPV4);
   if (overflow)
      reportExceptionLine("IP number component is out of range [0-255]");
   else
      latestIPV4=addr|b;
}

void MyFlexLexer::setupMask()
{
   IPV4  testBit;

   for (testBit=0x8000000;testBit!=0 && (latestIPV4 & testBit)!=0;testBit>>=1);

   if (testBit!=0)
      for (;testBit!=0 && (latestIPV4 & testBit)==0;testBit>>=1);

   if (testBit==0)
   {
      currentMask=latestIPV4;
      ipv4Params|=IPV4_MASK_SPECIFIED;
   }
   else
      reportExceptionLine("Invalid mask.");
}

void MyFlexLexer::setupGateway()
{
   currentGateway=latestIPV4;
   ipv4Params|=IPV4_GW_SPECIFIED;
}

const char *MyFlexLexer::emitIPV4(IPV4 ipV4)
{
   (*netTestsStream) << (ipV4 >> 24) << "." << ((ipV4>>16)&0xff) << "."
                    << ((ipV4 >> 8)&0xff) << "." << (ipV4 & 0xff);

   return "";
}

void MyFlexLexer::performAddress()
{
   if (ipv4Params == IPV4_CONF_COMPLETE)
   {
      (*netTestsStream) << "M: " << emitIPV4(currentMask)
                        << " G: " << emitIPV4(currentGateway)
                        << " A: " << emitIPV4(latestIPV4) << " => "
                        << (((currentGateway & currentMask)==(latestIPV4 & currentMask)) ? "in" : "out")
                        << endl;
   }
   else
      reportExceptionLine("IPV4 address test failure due to incomplete configuration.");
}
