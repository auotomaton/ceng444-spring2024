// Use the symbols from the std name space. This convenience for stream related symbols.
using namespace std;

// Stream related library headers
#include <iostream>
#include <fstream>

// The standard header file for all flex generated lexers. This comes with the flex tool.
// All of the lexers are based on the declarations made in the FelxLexer.h
#include "FlexLexer.h"

// The declarations for customized lexer that subclasses
#include "MyFlexLexer.h"

// Declare and instantiate the lexer.
// See details in MyFlexLexer.h and MyFlexLexer.cpp
MyFlexLexer *lexer=new MyFlexLexer();

int main(int argc, char **argv)
{
   // Check the command line argument count. It must be 2 as the usage is <prog-name> <input-file>
   if (argc==2)
   {
      // argv[0] is the program name and argv[1] is the <input-file>
      // Open the input file by instantiating an ifstream.
      // Note that the constructor used below tries to open the file automatically.
      ifstream is(argv[1]);

      // Check if the  open was successful
      if (is.is_open())
      {
         // Reset the whole processing parameters of the lexer.
         lexer->resetProcessingParameters();

         // The following binds the input stream of the lexer to
         // the input file.
         lexer->switch_streams(&is);

         // This is the main loop that consumes all of the lexemes.
         // The lexer returns null pointer when it runs out of lexemes.
         // The action codes triggered in the process is the key to the solution.
         // The action codes are defined in MyFlexLexer and referred from the
         // lex definition file (project01lex.l) and the cpp module generated from
         // the lex definition file (lex.yy.cc)
         while (lexer->yylex() != 0)
            ;

         lexer->finalizeProcessing();
         // Report the number of the lines processed in the file.
         cout << "Processed "<< lexer->getLineCount() << " lines." << endl;
         // Close the input file.
         is.close();
      }
      else
         // Display an error messagge telling that the input file was not found.
         cout << "File '" << argv[1] << "' not found." << endl;
   }
   else
      // Display an error message suggesting correct usage.
      cout << "Usage:project1part1 <input-file-name>" << endl;

   return 0;
}
