#ifndef MYFLEXLEXER_H_
#define MYFLEXLEXER_H_

// The size of the vector (lineTokenBag) that collects the tokens detected in a single line.
#define MAXTOKENINLINE 2

// The identifiers for the tokens that can be recognized. These are the values
// stored in the vector (lineTokenBag)
#define TOKEN_NUMBER       1
#define TOKEN_IPV4         2
#define TOKEN_GATEWAY      3
#define TOKEN_MASK         4
#define TOKEN_ADDRESS      5
#define TOKEN_RESET        6
#define TOKEN_IDENTIFIER   7

// Useful constants to encode bit-mapped ipv4 configuration state

// Bit value to indicate gateway was specified
#define IPV4_GW_SPECIFIED     1
// Bit value to indicate mask was specified
#define IPV4_MASK_SPECIFIED   2
// Combined bits to signify the complete configuration i.e. all bits set
#define IPV4_CONF_COMPLETE    (IPV4_GW_SPECIFIED | IPV4_MASK_SPECIFIED)

// Convenience type of IPV4. Note that this should be at least 32 bit integer.
typedef unsigned int IPV4;

// The class that subclasses yyFlexLexer which was produced by the flex tool.
// MyFlexLexer customizes the auto-generated yyFlexLexer to add the capacity
// to solve the problems in the assignment. Note that the actions in the
// relevant lex file (project01lex.l) have references to some of the methods
// declared here.
class MyFlexLexer : public yyFlexLexer
{
   private:
      // Collective declarations for the output streams required.
      ofstream *exceptionsStream,
               *netTestsStream,
               *sequencesStream,
               *identifiersStream;

      int      errInLine;                    // Counts the number of the errors in line.
                                             // This is reset to zero after a line gets processed.
      int      lineCount,                    // The number of current line. At the end, it contains
                                             // total number of the lines processed.
               lineTokenBag[MAXTOKENINLINE], // The vector of tokens detected in a line.
                                             // This is large enough to solve the problem.
               tokensInLine;                 // Actual number of the tokens detected in line.

      // Number sequence processing members
      // Pay attention to the members that help generation of
      // descriptive statistical figures. There is no need to hold the
      // array of numbers detected.
      double   latestNumber,  // Latest number recognized
               latestElement; // latest element of the sequence before latest number added
      double   sx2,           // Sum of recognized "number squared"s.
               sx,            // Sum of recognized numbers
               minimum,       // The minimum detected
               maximum;       // The maximum detected
      int      n;             // Count of numbers
      int      ltc,           // Count of "less than" findings
               gtc,           // Count of "greater than" findings
               sn;            // Number of sequences

      // IPV4 processing members
      IPV4     latestIPV4;    // Latest IPV4 recognized
      IPV4     currentMask,   // The current mask IPV4 value, which is part of configuration.
               currentGateway;// The current gateway IPV4 value, which is part of configuration.
      int      ipv4Params;    // The bitmap of configuration completion. See, setupMask,
                              // setupGateway, and performAddress for details.
                              // The bits IPV4_GW_SPECIFIED, IPV4_GW_SPECIFIED are used only.

      // Identifier processing members
      int      identifierCount;
   public:
      // Simple getter for lineCount.
      int getLineCount()
      {
         return lineCount;
      }

      void alertUnrecognized();  // Generates an error using current line (lineCount).
      void processLineData();    // Triggered when an end of line is detected by the lexer.
                                 // See the relevant rule in project01lex.l

      void reportExceptionLine(const char *msg);   // Generates an error log line in exceptions.txt
                                                   // Uses the current line number (lineCount).
      void resetProcessingParameters();      // Resets the whole set of processing parameters.
                                             // This must be called before processing each
                                             // input file.
      void resetLineProcessingParameters();  // This must be called before analyzing a line
                                             // content.
      void finalizeProcessing();             // This method must be called after consuming the
                                             // set of lexemes. It performs final processing steps
                                             // (such as processing of the final line) and,
                                             // closes the output streams,

      void registerTokenInLine(int tokenId); // Adds a token to the token vector (lineTokenBag)
                                             // with capacity checking. See the references from
                                             // the MyLexer.cpp and project01lex.l files.
                                             // See also references from lex.yy.cc to understand
                                             // how the flex utility places the action codes.

      void resetNumberSequenceProcessing();  // Resets the number sequence processing parameters.

      void processNumber(const char *numberLexeme);   // Tries to convert the recognized lexeme
                                                      // to a double value. This is referred from
                                                      // the lex definition file (project01lex.l).
      void reportNumberSequence();                    // Generates the output for the

      void processIPV4Adress(const char *ipv4Lexeme); // Analyzes the ipv4 lexeme with further
                                                      // semantic constrains. Either reports an
                                                      // error of evaluates 32 bit IPV4 value
                                                      // as the latest IPV4 value.
      void setupMask();                               // Analyzes the latest IPV4 further
                                                      // for mask semantics and sets it
                                                      // as mask if found valid. Otherwise,
                                                      // Raises an error
      void setupGateway();                            // Sets up the latest recognized
                                                      // IPV4 as gateway.
      void performAddress();                          // Performs the subnet boundeds
                                                      // IPV4 as gateway.
      const char *emitIPV4(IPV4 ipv4);                // Sends the human readable form of
                                                      // the specified IPV4 to the relevant
                                                      // output stream

      MyFlexLexer();                                  // The holy constructor!
};

#endif /* MYFLEXLEXER_H_ */
