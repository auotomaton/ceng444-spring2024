/*
 * MyParser.h
 *
 *  Created on: Mar 24, 2024
 *      Author: erkan
 */

#ifndef MYPARSER_H_
#define MYPARSER_H_

namespace yy
{
   class MyParserBase;
};

#include "ir.h"

class MyFlexLexer;

class MyParser
{
   yy::MyParserBase *base;
   MyFlexLexer      *lexer;
   ofstream         *os;

   int   varDeclCount=0,
         evaluationStatCount=0,
         whileStatCount=0,
         ifStatCount=0,
         ifElseStatCount=0,
         appendStatCount=0,
         compoundStatCount=0,
         tableLiteralCount=0,
         functionCallCount=0,
         divCount=0,
         mutationCount=0,
         matCount=0;

   // Variable to integrate token semantics
   yy::MyParserBase::semantic_type *lval;

   int              parseErrorLine=-1;

   string *makeString(const char *rawStr);
   int hexDigit(char c);
public:
   MyParser(ofstream *os);
   ~MyParser();

   void parse(yy::MyParserBase *base, ifstream *is);
   int lex(yy::MyParserBase::value_type *lval);

   int getId();
   int getStr();
   int getNumber();
   int getDPrefId();

   void setParseErrorLine();
   int getParseErrorLine();

   void reportFindings();
   void reportError();

   // Parser actions
   void processVarDecl();
   void processEvaluationStat();
   void processWhileStat();
   void processIfStat();
   void processIfElseStat();
   void processAppendStat();
   void processCompoundStat();
   void processTableLiteral();
   void processFunctionCall();
   void processDiv();
   void processMutation();
   void processMat();
};


#endif /* MYPARSER_H_ */
