using namespace std;

#include "MyParser.h"

// Type descriptors and type signatures

TQLTypeDesc::TQLTypeDesc(TQLType type)
      :type(type)
{
}

void TQLTypeDesc::addMember(TQLVarDesc *memDesc)
{
   if (members==nullptr)
      members=new TQLVarList();

   members->addVar(memDesc);
}

bool TQLTypeDesc::equals(TQLTypeDesc *other)
{
   if (type!=other->type)
      return false;


   int c=members->count();

   if (c==other->members->count())
   {
      if (c>0)
      {
         for (int i=0;i<c;i++)
            if (!(*members)[i]->isTypeEqual((*members)[i]))
               return false;
      }
   }
   else
      return false;

   return true;
}

TQLTypeDesc::~TQLTypeDesc()
{
   if (members!=nullptr)
      delete members;
}

void TQLTypeDesc::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"type\": \"";

   switch (type)
   {
      case TQLType::typeBool:
         (*outStream) << "boolean";
         break;
      case TQLType::typeNumber:
         (*outStream) << "number";
         break;
      case TQLType::typeString:
         (*outStream) << "string";
         break;
      case TQLType::typeObject:
         (*outStream) << "object";
         break;
   }
   (*outStream) << "\"";

   if (type==TQLType::typeObject)
   {
      (*outStream) << ", \"members\" : ";
      if (members!=nullptr)
         members->writeAsJSON(outStream);
      else
         (*outStream) << "null";
   }

   (*outStream) << "}";
}

// TQLVarDesc
TQLVarDesc::TQLVarDesc(TQLTypeDesc *varType, TQLIdentifier *id)
   :varType(varType), id(id)
{
   address=-1;
}

TQLVarDesc::~TQLVarDesc()
{
   delete varType;
   delete id;
}

bool TQLVarDesc::isTypeEqual(TQLVarDesc *other)
{
   return varType->equals(other->varType);
}

void TQLVarDesc::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"id\": \"";
   id->writeAsJSON(outStream);

   (*outStream) << "\", \"address\": " << address << "";

   (*outStream) << ", \"type\":";
   varType->writeAsJSON(outStream);
   (*outStream) << "}";
}

//TQLIdentifier class
TQLIdentifier::TQLIdentifier(string *id)
   :dIndex(-1), id(id)
{
}

TQLIdentifier::TQLIdentifier(int dIndex, string *id)
   :dIndex(dIndex), id(id)
{
}

bool TQLIdentifier::equals(string *id)
{
   if (dIndex!=-1)
      return false;

   return this->id->compare(*id)==0;
}

bool TQLIdentifier::equals(TQLIdentifier *other)
{
   if (dIndex!=other->dIndex)
      return false;

   return id->compare(*other->id)==0;
}

TQLIdentifier::~TQLIdentifier()
{
   delete id;
}

void TQLIdentifier::writeAsJSON(ofstream *outStream)
{
   if (dIndex>0)
      (*outStream) << "$" << dIndex << ".";

   (*outStream) << *id;
}

// Expression node class
TQLExpNode::TQLExpNode(int opCode)
      :opCode(opCode)
{
}

TQLExpNode::TQLExpNode(TQLIdentifier *id)
      :opCode(OP_ID), id(id)
{
}

TQLExpNode::TQLExpNode(string *strConstant)
   :strConstant(strConstant), opCode(OP_CONST), typeDesc(new TQLTypeDesc(TQLType::typeString))
{
}

TQLExpNode::TQLExpNode(double numConstant)
   :numConstant(numConstant), opCode(OP_CONST), typeDesc(new TQLTypeDesc(TQLType::typeNumber))
{
}

TQLExpNode::TQLExpNode(bool boolConstant)
   :boolConstant(boolConstant), opCode(OP_CONST), typeDesc(new TQLTypeDesc(TQLType::typeBool))
{
}

TQLExpNode::TQLExpNode(TQLExpNode *tableNameExp)
   :boolConstant(boolConstant), opCode(OP_CONST), typeDesc(new TQLTypeDesc(TQLType::typeObject))
{
   left=tableNameExp;
}

void TQLExpNode::writeStrValue(ofstream *os)
{
   static  unsigned char const *hd=(unsigned char const *)"0123456789abcdef";
   string  t=string();
   int     l=(int)strConstant->length();

   t+='"';
   for (int i=0;i<l;i++)
   {
      char c=(*strConstant)[i];

      switch (c)
      {
         case '\n':
            t+="\\n";
            break;
         case '\t':
            t+="\\t";
            break;
         case '\r':
            t+="\\r";
            break;
         case '\\':
            t+="\\\\";
            break;
         default:
            if (c<32)
            {
               t+="\\x";
               t+=hd[c>>4];
               t+=hd[c&0xf];
            }
            else
               t+=(*strConstant)[i];
      }
   }

   t+='"';
   (*os) << t;
}

const char *TQLExpNode::opStr()
{
   switch (opCode)
   {
      case OP_CONST:
         return "const";
      case OP_ID:
         return "id";
      case OP_CALL:
         return "call()";
      case OP_MUT:
         return "mutation[]";
      case yy::MyParserBase::token::ASSIGN:
         return "=";
      case yy::MyParserBase::token::PLUS:
         return "+";
      case yy::MyParserBase::token::MINUS:
         return "-";
      case yy::MyParserBase::token::DIV:
         return "/";
      case yy::MyParserBase::token::MUL:
         return "*";
      case yy::MyParserBase::token::EQ:
         return "==";
      case yy::MyParserBase::token::NEQ:
         return "!=";
      case yy::MyParserBase::token::LT:
         return "<";
      case yy::MyParserBase::token::LTE:
         return "<=";
      case yy::MyParserBase::token::GT:
         return ">";
      case yy::MyParserBase::token::GTE:
         return ">=";
      case yy::MyParserBase::token::BOR:
         return "||";
      case yy::MyParserBase::token::BAND:
         return "&&";
      case yy::MyParserBase::token::COMMA:
         return ",";
      case yy::MyParserBase::token::MAT:
         return "->";
   }

   return "unknown";
}

void TQLExpNode::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"op\": \"" << opStr() << "\", \"opCode\":\"" << opCode << "\"";
   if (typeDesc!=nullptr)
   {
      (*outStream) << ", \"type\": ";
      typeDesc->writeAsJSON(outStream);
   }

   switch (opCode)
   {
      case OP_CONST:
         switch (typeDesc->type)
         {
            case TQLType::typeBool:
               (*outStream) << ", \"value\": " << boolConstant;
               break;
            case TQLType::typeNumber:
               (*outStream) << ", \"value\": " << numConstant;
               break;
            case TQLType::typeString:
               (*outStream) << ", \"value\": ";
               writeStrValue(outStream);
               break;
         }
         break;
      case OP_ID:
         (*outStream)<<", \"id\":\"";
         id->writeAsJSON(outStream);
         (*outStream)<<"\"";
         break;
   }

   if (left!=nullptr)
   {
      (*outStream) << ", \"left\":";
      left->writeAsJSON(outStream);
   }

   if (right!=nullptr)
   {
      (*outStream) << ", \"right\":";
      right->writeAsJSON(outStream);
   }

   (*outStream) << "}";
}

TQLExpNode::~TQLExpNode()
{
   if (left!=nullptr)
      delete left;

   if (right!=nullptr)
      delete right;

   switch (opCode)
   {
      case OP_CONST:
         switch (typeDesc->type)
         {
            case TQLType::typeString:
               if (strConstant!=nullptr)
               {
                  delete strConstant;
                  id=nullptr;
               }
               break;
         }
         break;
      case OP_ID:
         if (id!=nullptr)
         {
            delete id;
            id=nullptr;
         }
         break;
   }
   delete typeDesc;
}

void TQLExpNode::emitIC(TQLIC *ic)
{
   if (left!=nullptr)
      left->emitIC(ic);

   if (right!=nullptr)
      right->emitIC(ic);

   if (typeDesc!=nullptr)
      ic->addInstruction(new TQLICInst(opCode, 0, typeDesc->type));
   else
      ic->addInstruction(new TQLICInst(opCode, 0, TQLType::typeNA));
}

// TQLNode

TQLNode::TQLNode()
{
}

TQLNode::~TQLNode()
{
}

// TQLVarList
TQLVarList::TQLVarList()
{
}

bool TQLVarList::addVar(TQLVarDesc *item)
{
   if (findVar(item->id)!=nullptr)
      return false;

   if (vars==nullptr)
      vars=new vector<TQLVarDesc *>();

   vars->push_back(item);

   return false;
}

TQLVarDesc *TQLVarList::findVar(TQLIdentifier *id)
{
   if (vars!=nullptr)
      for (int i=(int)vars->size()-1;i>=0;i--)
         if ((*vars)[i]->id->equals(id))
               return (*vars)[i];

   return nullptr;
}

TQLVarDesc *TQLVarList::operator[] (int ndx)
{
   return (*vars)[ndx];
}

int TQLVarList::count()
{
   if (vars!=nullptr)
      return (int)vars->size();

   return 0;
}

TQLVarList::~TQLVarList()
{
   if (vars!=nullptr)
   {
      for (int i=(int)vars->size()-1;i>=0;i--)
         delete (*vars)[i];

      delete vars;
   }
}

void TQLVarList::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "[";

   if (vars!=nullptr)
   {
      size_t c=vars->size();

      for (int i=0;i<c;i++)
      {
         if (i>0)
            (*outStream) << ", ";

         (*vars)[i]->writeAsJSON(outStream);
      }

   }
   (*outStream) << "]";
}


// TQLVarTable
TQLVarTable::TQLVarTable()
{
}


TQLVarTable::~TQLVarTable()
{
}

// TQLEvaStatement
TQLEvaStatement::TQLEvaStatement(TQLExpNode *exp)
   :TQLStatement(), exp(exp)
{
}

TQLEvaStatement::~TQLEvaStatement()
{
   delete exp;
}

void TQLEvaStatement::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"statement\": \"evaluation\", \"expression\": ";
   exp->writeAsJSON(outStream);
   (*outStream) << "}";
}

void TQLEvaStatement::emitIC(TQLIC *ic)
{
   exp->emitIC(ic);
}

// TQLLetStatement
TQLLetStatement::TQLLetStatement(TQLLetAssignment *letAssignment)
   :TQLStatement()
{
   letAssignments=new vector<TQLLetAssignment *>();
   letAssignments->push_back(letAssignment);
}

TQLLetStatement::~TQLLetStatement()
{
   if (letAssignments!=nullptr)
   {
      for (int i=(int)letAssignments->size()-1;i>=0;i--)
         delete (*letAssignments)[i];

      delete letAssignments;
   }
}

void TQLLetStatement::appendLetAssignment(TQLLetAssignment *letAssignment)
{
   letAssignments->push_back(letAssignment);
}

void TQLLetStatement::writeAsJSON(ofstream *outStream)
{
   int cnt=(int)letAssignments->size();

   (*outStream) << "{\"statement\": \"let\", \"assignments\": [";

   for (int i=0;i<cnt;i++)
   {
      TQLLetAssignment *la=(*letAssignments)[i];
      if (i>0)
         (*outStream) << ", ";

      (*outStream) << "{\"id\":\""<< *la->id << "\", \"expression\": ";

      la->exp->writeAsJSON(outStream);

      (*outStream) << "}";
   }
   (*outStream) << "]}";
}

void TQLLetStatement::emitIC(TQLIC *ic)
{
   int cnt=letAssignments->size();

   for (int i=0;i<cnt;i++)
   {
      TQLLetAssignment *la=(*letAssignments)[i];

      ic->addInstruction(new TQLICInst(OP_SETV, 0, TQLType::typeNA));
      la->exp->emitIC(ic);
   }
}

// TQLAppendStatement
TQLAppendStatement::TQLAppendStatement(TQLExpNode *exp)
   : TQLStatement(), exp(exp)
{
}

TQLAppendStatement::~TQLAppendStatement()
{
   delete exp;
}

void TQLAppendStatement::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"statement\": \"append\", \"expression\": ";

   exp->writeAsJSON(outStream);

   (*outStream) << "}";
}

void TQLAppendStatement::emitIC(TQLIC *ic)
{
   exp->emitIC(ic);
   ic->addInstruction(new TQLICInst(OP_CALL, -1, TQLType::typeNA));
}

// TQLStatement
TQLStatement::TQLStatement()
{
   parent=nullptr;
   vars=nullptr;
}

TQLStatement::~TQLStatement()
{
}

// TQLCompoundStatement
TQLCompoundStatement::TQLCompoundStatement()
   :TQLStatement()
{
   stats=nullptr;
}

TQLCompoundStatement::TQLCompoundStatement(TQLStatement *statement)
   :TQLStatement()
{
   stats=new vector<TQLStatement *>();

   stats->push_back(statement);
}

TQLCompoundStatement::~TQLCompoundStatement()
{
   if (stats!=nullptr)
   {
      for (int i=(int)stats->size()-1;i>=0;i--)
         delete (*stats)[i];

      delete stats;
   }
}

void TQLCompoundStatement::appendStatement(TQLStatement *statement)
{
   stats->push_back(statement);
}

void TQLCompoundStatement::writeAsJSON(ofstream *outStream)
{
   int cnt=stats->size();

   (*outStream) << "{\"statement\": \"compound\", \"statements\": [";

   for (int i=0;i<cnt;i++)
   {
      TQLStatement *la=(*stats)[i];
      if (i>0)
         (*outStream) << ", ";

      la->writeAsJSON(outStream);
   }
   (*outStream) << "]}";
}

void TQLCompoundStatement::emitIC(TQLIC *ic)
{
   int cnt=stats->size();

   for (int i=0;i<cnt;i++)
   {
      TQLStatement *la=(*stats)[i];
      la->emitIC(ic);
   }
}

// TQLWhileStatement
TQLWhileStatement::TQLWhileStatement(TQLExpNode *exp, TQLStatement *loopStat)
   : TQLStatement(), exp(exp), loopStat(loopStat)
{
}

TQLWhileStatement::~TQLWhileStatement()
{
   delete exp;
   delete loopStat;
}

void TQLWhileStatement::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"statement\": \"while\", \"expression\": ";
   exp->writeAsJSON(outStream);
   (*outStream) << ", \"loopStatement\": ";
   loopStat->writeAsJSON(outStream);
   (*outStream) << "}";
}

void TQLWhileStatement::emitIC(TQLIC *ic)
{
   int p0=ic->count();
   exp->emitIC(ic);

   int p1=ic->count();
   ic->addInstruction(new TQLICInst(OP_JF, 0, TQLType::typeNA));
   loopStat->emitIC(ic);

   ic->addInstruction(new TQLICInst(OP_JMP, p0, TQLType::typeNA));
   TQLICInst *inst=ic->instructionAt(p1);
   inst->p1=ic->count();
}

// TQLIfStat
TQLIfStatement::TQLIfStatement(TQLExpNode *exp, TQLStatement *trueStat)
   : TQLStatement(), exp(exp), trueStat(trueStat), falseStat(nullptr)
{
}

TQLIfStatement::TQLIfStatement(TQLExpNode *exp, TQLStatement *trueStat, TQLStatement *falseStat)
   : TQLStatement(), exp(exp), trueStat(trueStat), falseStat(falseStat)
{
}

TQLIfStatement::~TQLIfStatement()
{
   delete exp;
   delete trueStat;

   if (falseStat!=nullptr)
      delete falseStat;
}

void TQLIfStatement::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"statement\": \"if\", \"expression\": ";
   exp->writeAsJSON(outStream);
   (*outStream) << ", \"trueStatement\": ";
   trueStat->writeAsJSON(outStream);

   if (falseStat!=nullptr)
   {
      (*outStream) << ", \"falseStatement\": ";
      falseStat->writeAsJSON(outStream);
   }

   (*outStream) << "}";
}

void TQLIfStatement::emitIC(TQLIC *ic)
{
   exp->emitIC(ic);

   int p1=ic->count();
   ic->addInstruction(new TQLICInst(OP_JF, 0, TQLType::typeNA));
   trueStat->emitIC(ic);

   if (falseStat!=nullptr)
   {
      int p2=ic->count();

      ic->addInstruction(new TQLICInst(OP_JMP, 0, TQLType::typeNA));

      TQLICInst *inst=ic->instructionAt(p1);
      inst->p1=ic->count();
      falseStat->emitIC(ic);

      inst=ic->instructionAt(p2);
      inst->p1=ic->count();
   }
   else
   {
      TQLICInst *inst=ic->instructionAt(p1);
      inst->p1=ic->count();
   }
}

// TQLMsg
TQLMsg::TQLMsg(TQLMsgType msgType, int msgCode, int line, string *msg)
   : msgType(msgType), msgCode(msgCode), line(line), msg(msg)
{
}

TQLMsg::~TQLMsg()
{
   delete msg;
}

void TQLMsg::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{";

   (*outStream) << "\"code\": " << msgCode;
   (*outStream) << ", \"line\": " << line;
   (*outStream) << ", \"type\": " << ((msgType == TQLMsgType::error) ? "Error" : ((msgType == TQLMsgType::warning) ? "Warning" : "Info"));
   (*outStream) << ", \"message\": \"" << line << "\"";

   (*outStream) << "}";
}

// TQLMsgList
TQLMsgList::TQLMsgList()
{
   msgList=new vector<TQLMsg *>();
}

TQLMsgList::~TQLMsgList()
{
   int cnt=msgList->size();

   for (int i=0;i<cnt;i++)
      delete (*msgList)[i];

   delete msgList;
}

void TQLMsgList::add(TQLMsg *msg)
{
   msgList->push_back(msg);
}

void TQLMsgList::writeAsJSON(ofstream *outStream)
{
   int cnt=msgList->size();

   (*outStream) << "[";

   for (int i=0;i<cnt;i++)
   {
      (*msgList)[i]->writeAsJSON(outStream);
   }

   (*outStream) << "]";
}

// TQLICInst
TQLICInst::TQLICInst(int opCode, int p1)
   :opCode(opCode), p1(p1), type(TQLType::typeNA)
{
}

TQLICInst::TQLICInst(int opCode, int p1, TQLType type)
   :opCode(opCode), p1(p1), type(type)
{
}

TQLICInst::~TQLICInst()
{
}

const char *TQLICInst::opStr()
{
   switch (opCode)
   {
      case OP_CONST:
         return "const";
      case OP_ID:
         return "id";
      case OP_CALL:
         return "call()";
      case OP_MUT:
         return "mutation[]";
      case OP_JMP:
         return "jmp";
      case OP_JT:
         return "jt";
      case OP_JF:
         return "jf";
      case OP_SETV:
         return "setv";
      case OP_ADDSP:
         return "addsp";
      case yy::MyParserBase::token::ASSIGN:
         return "asn";
      case yy::MyParserBase::token::PLUS:
         return "add";
      case yy::MyParserBase::token::MINUS:
         return "sub/neg";
      case yy::MyParserBase::token::DIV:
         return "/";
      case yy::MyParserBase::token::MUL:
         return "mul";
      case yy::MyParserBase::token::EQ:
         return "equ";
      case yy::MyParserBase::token::NEQ:
         return "neq";
      case yy::MyParserBase::token::LT:
         return "lt";
      case yy::MyParserBase::token::LTE:
         return "lte";
      case yy::MyParserBase::token::GT:
         return "gt";
      case yy::MyParserBase::token::GTE:
         return "gte";
      case yy::MyParserBase::token::BOR:
         return "lor";
      case yy::MyParserBase::token::BAND:
         return "land";
      case yy::MyParserBase::token::MAT:
         return "mat";
   }

   return "unknown";
}
void TQLICInst::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"mnemonic\":\"" << opStr() << "\"";
   (*outStream) << ", \"opCode\":" << opCode;
   (*outStream) << ", \"p1\":" << p1;
   (*outStream) << ", \"type\":" << (int)type;
   (*outStream) << "}";
}

// TQLIC
TQLIC::TQLIC()
{
   code=new vector<TQLICInst *>();
}

TQLIC::~TQLIC()
{
   int cnt=code->size();

   for (int i=0;i<cnt;i++)
      delete (*code)[i];

   delete code;
}

int TQLIC::count()
{
   return (int)code->size();
}

void TQLIC::addInstruction(TQLICInst *inst)
{
   code->push_back(inst);
}

TQLICInst *TQLIC::instructionAt(int loc)
{
   return (*code)[loc];
}

void TQLIC::writeAsJSON(ofstream *outStream)
{
   int cnt=code->size();

   (*outStream) << "[";
   for (int i=0;i<cnt;i++)
   {
      if (i>0)
         (*outStream) << ", ";
      (*code)[i]->writeAsJSON(outStream);
   }
   (*outStream) << "]";
}


//TQLIR
TQLIR::TQLIR()
{
}

TQLIR::~TQLIR()
{
}

void TQLIR::writeAsJSON(ofstream *outStream)
{
   (*outStream) << "{\"messages\":";
   tqlMsgList->writeAsJSON(outStream);

   if (tqlStat!=nullptr)
   {
      (*outStream) << ", \"graphIR\":";
      tqlStat->writeAsJSON(outStream);
   }

   if (tqlIC!=nullptr)
   {
      (*outStream) << ", \"linearIR\":";
      tqlIC->writeAsJSON(outStream);
   }

   (*outStream) << "}";
}

void TQLIR::emitIC()
{
   // Error count control must be here
   tqlIC=new TQLIC();
   tqlStat->emitIC(tqlIC);
}
