// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.



// First part of user prologue.
#line 4 "tqlparse.y"

using namespace std;
#include <iostream>
#include <fstream>

#line 47 "tqlparse.tab.cc"


#include "tqlparse.tab.hh"


// Unqualified %code blocks.
#line 17 "tqlparse.y"

   #include "MyParser.h"
   #define yylex(x) driver->lex(x)

#line 59 "tqlparse.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif



// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

namespace yy {
#line 132 "tqlparse.tab.cc"

  /// Build a parser object.
  MyParserBase::MyParserBase (MyParser *driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  MyParserBase::~MyParserBase ()
  {}

  MyParserBase::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/

  // basic_symbol.
  template <typename Base>
  MyParserBase::basic_symbol<Base>::basic_symbol (const basic_symbol& that)
    : Base (that)
    , value (that.value)
  {}


  /// Constructor for valueless symbols.
  template <typename Base>
  MyParserBase::basic_symbol<Base>::basic_symbol (typename Base::kind_type t)
    : Base (t)
    , value ()
  {}

  template <typename Base>
  MyParserBase::basic_symbol<Base>::basic_symbol (typename Base::kind_type t, YY_RVREF (value_type) v)
    : Base (t)
    , value (YY_MOVE (v))
  {}


  template <typename Base>
  MyParserBase::symbol_kind_type
  MyParserBase::basic_symbol<Base>::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }


  template <typename Base>
  bool
  MyParserBase::basic_symbol<Base>::empty () const YY_NOEXCEPT
  {
    return this->kind () == symbol_kind::S_YYEMPTY;
  }

  template <typename Base>
  void
  MyParserBase::basic_symbol<Base>::move (basic_symbol& s)
  {
    super_type::move (s);
    value = YY_MOVE (s.value);
  }

  // by_kind.
  MyParserBase::by_kind::by_kind () YY_NOEXCEPT
    : kind_ (symbol_kind::S_YYEMPTY)
  {}

#if 201103L <= YY_CPLUSPLUS
  MyParserBase::by_kind::by_kind (by_kind&& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {
    that.clear ();
  }
#endif

  MyParserBase::by_kind::by_kind (const by_kind& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {}

  MyParserBase::by_kind::by_kind (token_kind_type t) YY_NOEXCEPT
    : kind_ (yytranslate_ (t))
  {}



  void
  MyParserBase::by_kind::clear () YY_NOEXCEPT
  {
    kind_ = symbol_kind::S_YYEMPTY;
  }

  void
  MyParserBase::by_kind::move (by_kind& that)
  {
    kind_ = that.kind_;
    that.clear ();
  }

  MyParserBase::symbol_kind_type
  MyParserBase::by_kind::kind () const YY_NOEXCEPT
  {
    return kind_;
  }


  MyParserBase::symbol_kind_type
  MyParserBase::by_kind::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }



  // by_state.
  MyParserBase::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  MyParserBase::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  MyParserBase::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  MyParserBase::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  MyParserBase::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  MyParserBase::symbol_kind_type
  MyParserBase::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  MyParserBase::stack_symbol_type::stack_symbol_type ()
  {}

  MyParserBase::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.value))
  {
#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  MyParserBase::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.value))
  {
    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  MyParserBase::stack_symbol_type&
  MyParserBase::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    value = that.value;
    return *this;
  }

  MyParserBase::stack_symbol_type&
  MyParserBase::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    value = that.value;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  MyParserBase::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);

    // User destructor.
    YY_USE (yysym.kind ());
  }

#if YYDEBUG
  template <typename Base>
  void
  MyParserBase::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " (";
        YY_USE (yykind);
        yyo << ')';
      }
  }
#endif

  void
  MyParserBase::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  MyParserBase::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  MyParserBase::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  MyParserBase::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  MyParserBase::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  MyParserBase::debug_level_type
  MyParserBase::debug_level () const
  {
    return yydebug_;
  }

  void
  MyParserBase::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  MyParserBase::state_type
  MyParserBase::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  MyParserBase::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  MyParserBase::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  MyParserBase::operator() ()
  {
    return parse ();
  }

  int
  MyParserBase::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            yyla.kind_ = yytranslate_ (yylex (&yyla.value));
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* If YYLEN is nonzero, implement the default value of the
         action: '$$ = $1'.  Otherwise, use the top of the stack.

         Otherwise, the following line sets YYLHS.VALUE to garbage.
         This behavior is undocumented and Bison users should not rely
         upon it.  */
      if (yylen)
        yylhs.value = yystack_[yylen - 1].value;
      else
        yylhs.value = yystack_[0].value;


      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 2: // tql: statementList
#line 104 "tqlparse.y"
                   {(yylhs.value.tql)=driver->setTQL((yystack_[0].value.statementList));}
#line 589 "tqlparse.tab.cc"
    break;

  case 3: // tql: %empty
#line 105 "tqlparse.y"
     {(yylhs.value.tql)=driver->setTQL(nullptr);}
#line 595 "tqlparse.tab.cc"
    break;

  case 4: // statementList: statement
#line 108 "tqlparse.y"
                            {(yylhs.value.statementList)=driver->createCompoundStat((yystack_[0].value.statement));}
#line 601 "tqlparse.tab.cc"
    break;

  case 5: // statementList: statementList statement
#line 109 "tqlparse.y"
                                          {(yylhs.value.statementList)=driver->appendToCompoundStat((yystack_[1].value.statementList), (yystack_[0].value.statement));}
#line 607 "tqlparse.tab.cc"
    break;

  case 6: // statement: ifStatement
#line 112 "tqlparse.y"
                              {(yylhs.value.statement)=(yystack_[0].value.ifStatement);}
#line 613 "tqlparse.tab.cc"
    break;

  case 7: // statement: whileStatement
#line 113 "tqlparse.y"
                       {(yylhs.value.statement)=(yystack_[0].value.whileStatement);}
#line 619 "tqlparse.tab.cc"
    break;

  case 8: // statement: letStatement
#line 114 "tqlparse.y"
                     {(yylhs.value.statement)=(yystack_[0].value.letStatement);}
#line 625 "tqlparse.tab.cc"
    break;

  case 9: // statement: appendStatement
#line 115 "tqlparse.y"
                        {(yylhs.value.statement)=(yystack_[0].value.appendStatement);}
#line 631 "tqlparse.tab.cc"
    break;

  case 10: // statement: evaluationStatement
#line 116 "tqlparse.y"
                            {(yylhs.value.statement)=(yystack_[0].value.evaluationStatement);}
#line 637 "tqlparse.tab.cc"
    break;

  case 11: // statement: compoundStatement
#line 117 "tqlparse.y"
                          {(yylhs.value.statement)=(yystack_[0].value.compoundStatement);}
#line 643 "tqlparse.tab.cc"
    break;

  case 12: // ifStatement: IF LP expression RP statement elsePart
#line 120 "tqlparse.y"
                                                         {(yylhs.value.ifStatement)=driver->createIfStatement((yystack_[3].value.expression), (yystack_[1].value.statement), (yystack_[0].value.elsePart));}
#line 649 "tqlparse.tab.cc"
    break;

  case 13: // elsePart: ELSE statement
#line 122 "tqlparse.y"
                                 {(yylhs.value.elsePart)=(yystack_[0].value.statement);}
#line 655 "tqlparse.tab.cc"
    break;

  case 14: // elsePart: %empty
#line 123 "tqlparse.y"
                  {(yylhs.value.elsePart)=nullptr;}
#line 661 "tqlparse.tab.cc"
    break;

  case 15: // whileStatement: WHILE LP expression RP statement
#line 126 "tqlparse.y"
                                                   {(yylhs.value.whileStatement)=driver->createWhileStatement((yystack_[2].value.expression), (yystack_[0].value.statement));}
#line 667 "tqlparse.tab.cc"
    break;

  case 16: // compoundStatement: SOB statementList EOB
#line 129 "tqlparse.y"
                                        {(yylhs.value.compoundStatement)=(yystack_[1].value.statementList);}
#line 673 "tqlparse.tab.cc"
    break;

  case 17: // compoundStatement: SOB EOB
#line 130 "tqlparse.y"
                          {(yylhs.value.compoundStatement)=driver->createEmptyCompoundStatement();}
#line 679 "tqlparse.tab.cc"
    break;

  case 18: // letStatement: LET varDefList SEMICOLON
#line 133 "tqlparse.y"
                                         {(yylhs.value.letStatement)=(yystack_[1].value.varDefList);}
#line 685 "tqlparse.tab.cc"
    break;

  case 19: // varDefList: varDef
#line 136 "tqlparse.y"
               {(yylhs.value.varDefList)=driver->createLetStatement((yystack_[0].value.varDef));}
#line 691 "tqlparse.tab.cc"
    break;

  case 20: // varDefList: varDefList COMMA varDef
#line 137 "tqlparse.y"
                                {(yylhs.value.varDefList)=driver->appendToLetStatement((yystack_[2].value.varDefList), (yystack_[0].value.varDef));}
#line 697 "tqlparse.tab.cc"
    break;

  case 21: // varDef: ID ASSIGN assignSide
#line 139 "tqlparse.y"
                               {(yylhs.value.varDef)=driver->createLetAssignment((yystack_[2].value.ID), (yystack_[0].value.assignSide));}
#line 703 "tqlparse.tab.cc"
    break;

  case 22: // appendStatement: APPEND expression SEMICOLON
#line 142 "tqlparse.y"
                                              {(yylhs.value.appendStatement)=driver->createAppendStat((yystack_[1].value.expression));}
#line 709 "tqlparse.tab.cc"
    break;

  case 23: // evaluationStatement: expression SEMICOLON
#line 145 "tqlparse.y"
                                       {(yylhs.value.evaluationStatement)=driver->createEvaluationStat((yystack_[1].value.expression));}
#line 715 "tqlparse.tab.cc"
    break;

  case 24: // type: STRINGTYPE
#line 148 "tqlparse.y"
                             {(yylhs.value.type)=driver->createTypeDescriptor(TQLType::typeString);}
#line 721 "tqlparse.tab.cc"
    break;

  case 25: // type: NUMBERTYPE
#line 149 "tqlparse.y"
                             {(yylhs.value.type)=driver->createTypeDescriptor(TQLType::typeNumber);}
#line 727 "tqlparse.tab.cc"
    break;

  case 26: // type: BOOLTYPE
#line 150 "tqlparse.y"
                           {(yylhs.value.type)=driver->createTypeDescriptor(TQLType::typeBool);}
#line 733 "tqlparse.tab.cc"
    break;

  case 27: // expression: commaOperand
#line 153 "tqlparse.y"
                     {(yylhs.value.expression)=(yystack_[0].value.commaOperand);}
#line 739 "tqlparse.tab.cc"
    break;

  case 28: // expression: expression COMMA commaOperand
#line 154 "tqlparse.y"
                                      {(yylhs.value.expression)=driver->createExpressionNode((yystack_[2].value.expression), (yystack_[1].value.COMMA), (yystack_[0].value.commaOperand));}
#line 745 "tqlparse.tab.cc"
    break;

  case 29: // commaOperand: assignSide
#line 157 "tqlparse.y"
                             {(yylhs.value.commaOperand)=(yystack_[0].value.assignSide);}
#line 751 "tqlparse.tab.cc"
    break;

  case 30: // commaOperand: commaOperand ASSIGN assignSide
#line 158 "tqlparse.y"
                                                 {(yylhs.value.commaOperand)=driver->createCommaOperandNode((yystack_[2].value.commaOperand), (yystack_[1].value.ASSIGN), (yystack_[0].value.assignSide));}
#line 757 "tqlparse.tab.cc"
    break;

  case 31: // assignSide: booleanOperand
#line 161 "tqlparse.y"
                       {(yylhs.value.assignSide)=(yystack_[0].value.booleanOperand);}
#line 763 "tqlparse.tab.cc"
    break;

  case 32: // assignSide: assignSide booleanOp booleanOperand
#line 162 "tqlparse.y"
                                            {(yylhs.value.assignSide)=driver->createAssignSideNode((yystack_[2].value.assignSide), (yystack_[1].value.booleanOp), (yystack_[0].value.booleanOperand));}
#line 769 "tqlparse.tab.cc"
    break;

  case 33: // booleanOp: BAND
#line 165 "tqlparse.y"
             {(yylhs.value.booleanOp)=(yystack_[0].value.BAND);}
#line 775 "tqlparse.tab.cc"
    break;

  case 34: // booleanOp: BOR
#line 166 "tqlparse.y"
            {(yylhs.value.booleanOp)=(yystack_[0].value.BOR);}
#line 781 "tqlparse.tab.cc"
    break;

  case 35: // booleanOperand: logicalOperand
#line 169 "tqlparse.y"
                       {(yylhs.value.booleanOperand)=(yystack_[0].value.logicalOperand);}
#line 787 "tqlparse.tab.cc"
    break;

  case 36: // booleanOperand: booleanOperand logicalOp logicalOperand
#line 170 "tqlparse.y"
                                                {(yylhs.value.booleanOperand)=driver->createBooleanOperandNode((yystack_[2].value.booleanOperand), (yystack_[1].value.logicalOp), (yystack_[0].value.logicalOperand));}
#line 793 "tqlparse.tab.cc"
    break;

  case 37: // logicalOp: EQ
#line 173 "tqlparse.y"
           {(yylhs.value.logicalOp)=(yystack_[0].value.EQ);}
#line 799 "tqlparse.tab.cc"
    break;

  case 38: // logicalOp: NEQ
#line 174 "tqlparse.y"
            {(yylhs.value.logicalOp)=(yystack_[0].value.NEQ);}
#line 805 "tqlparse.tab.cc"
    break;

  case 39: // logicalOp: LT
#line 175 "tqlparse.y"
           {(yylhs.value.logicalOp)=(yystack_[0].value.LT);}
#line 811 "tqlparse.tab.cc"
    break;

  case 40: // logicalOp: LTE
#line 176 "tqlparse.y"
            {(yylhs.value.logicalOp)=(yystack_[0].value.LTE);}
#line 817 "tqlparse.tab.cc"
    break;

  case 41: // logicalOp: GT
#line 177 "tqlparse.y"
           {(yylhs.value.logicalOp)=(yystack_[0].value.GT);}
#line 823 "tqlparse.tab.cc"
    break;

  case 42: // logicalOp: GTE
#line 178 "tqlparse.y"
            {(yylhs.value.logicalOp)=(yystack_[0].value.GTE);}
#line 829 "tqlparse.tab.cc"
    break;

  case 43: // logicalOperand: term
#line 181 "tqlparse.y"
             {(yylhs.value.logicalOperand)=(yystack_[0].value.term);}
#line 835 "tqlparse.tab.cc"
    break;

  case 44: // logicalOperand: logicalOperand termOp term
#line 182 "tqlparse.y"
                                   {(yylhs.value.logicalOperand)=driver->createLogicalOperandNode((yystack_[2].value.logicalOperand), (yystack_[1].value.termOp), (yystack_[0].value.term));}
#line 841 "tqlparse.tab.cc"
    break;

  case 45: // termOp: PLUS
#line 185 "tqlparse.y"
             {(yylhs.value.termOp)=(yystack_[0].value.PLUS);}
#line 847 "tqlparse.tab.cc"
    break;

  case 46: // termOp: MINUS
#line 186 "tqlparse.y"
              {(yylhs.value.termOp)=(yystack_[0].value.MINUS);}
#line 853 "tqlparse.tab.cc"
    break;

  case 47: // term: factor
#line 189 "tqlparse.y"
               {(yylhs.value.term)=(yystack_[0].value.factor);}
#line 859 "tqlparse.tab.cc"
    break;

  case 48: // term: term factorOp factor
#line 190 "tqlparse.y"
                             {(yylhs.value.term)=driver->createTermNode((yystack_[2].value.term), (yystack_[1].value.factorOp), (yystack_[0].value.factor));}
#line 865 "tqlparse.tab.cc"
    break;

  case 49: // factorOp: MUL
#line 193 "tqlparse.y"
            {(yylhs.value.factorOp)=(yystack_[0].value.MUL);}
#line 871 "tqlparse.tab.cc"
    break;

  case 50: // factorOp: DIV
#line 194 "tqlparse.y"
            {(yylhs.value.factorOp)=(yystack_[0].value.DIV);}
#line 877 "tqlparse.tab.cc"
    break;

  case 51: // factorOp: MAT
#line 195 "tqlparse.y"
                      {(yylhs.value.factorOp)=(yystack_[0].value.MAT);}
#line 883 "tqlparse.tab.cc"
    break;

  case 52: // factor: unaryOperator unaryOperand
#line 198 "tqlparse.y"
                                             {(yylhs.value.factor)=driver->createUnaryOperatorNode((yystack_[1].value.unaryOperator), (yystack_[0].value.unaryOperand));}
#line 889 "tqlparse.tab.cc"
    break;

  case 53: // factor: unaryOperand
#line 199 "tqlparse.y"
                               {(yylhs.value.factor)=(yystack_[0].value.unaryOperand);}
#line 895 "tqlparse.tab.cc"
    break;

  case 54: // unaryOperator: MINUS
#line 202 "tqlparse.y"
                        {(yylhs.value.unaryOperator)=(yystack_[0].value.MINUS);}
#line 901 "tqlparse.tab.cc"
    break;

  case 55: // unaryOperator: NOT
#line 203 "tqlparse.y"
                      {(yylhs.value.unaryOperator)=(yystack_[0].value.NOT);}
#line 907 "tqlparse.tab.cc"
    break;

  case 56: // unaryOperand: unaryOperandBase postfixOperator
#line 206 "tqlparse.y"
                                               {(yylhs.value.unaryOperand)=driver->createUnaryOperandNode((yystack_[1].value.unaryOperandBase),(yystack_[0].value.postfixOperator));}
#line 913 "tqlparse.tab.cc"
    break;

  case 57: // unaryOperandBase: identifier
#line 209 "tqlparse.y"
                             {(yylhs.value.unaryOperandBase)=driver->createIdentifierNode((yystack_[0].value.identifier));}
#line 919 "tqlparse.tab.cc"
    break;

  case 58: // unaryOperandBase: ID LP expression RP
#line 210 "tqlparse.y"
                                      {(yylhs.value.unaryOperandBase)=driver->createCallNode((yystack_[3].value.ID), (yystack_[1].value.expression));}
#line 925 "tqlparse.tab.cc"
    break;

  case 59: // unaryOperandBase: ID LP RP
#line 211 "tqlparse.y"
                 {(yylhs.value.unaryOperandBase)=driver->createCallNode((yystack_[2].value.ID), nullptr);}
#line 931 "tqlparse.tab.cc"
    break;

  case 60: // unaryOperandBase: NUM
#line 212 "tqlparse.y"
                        {(yylhs.value.unaryOperandBase)=driver->createNumberConstantNode((yystack_[0].value.NUM));}
#line 937 "tqlparse.tab.cc"
    break;

  case 61: // unaryOperandBase: TRUE
#line 213 "tqlparse.y"
                        {(yylhs.value.unaryOperandBase)=driver->createBoolConstantNode(true);}
#line 943 "tqlparse.tab.cc"
    break;

  case 62: // unaryOperandBase: FALSE
#line 214 "tqlparse.y"
                        {(yylhs.value.unaryOperandBase)=driver->createBoolConstantNode(false);}
#line 949 "tqlparse.tab.cc"
    break;

  case 63: // unaryOperandBase: STR
#line 215 "tqlparse.y"
                        {(yylhs.value.unaryOperandBase)=driver->createStrConstantNode((yystack_[0].value.STR));}
#line 955 "tqlparse.tab.cc"
    break;

  case 64: // unaryOperandBase: LP expression RP
#line 216 "tqlparse.y"
                                   {(yylhs.value.unaryOperandBase)=(yystack_[1].value.expression);}
#line 961 "tqlparse.tab.cc"
    break;

  case 65: // unaryOperandBase: AT OB expression CB
#line 217 "tqlparse.y"
                                      {(yylhs.value.unaryOperandBase)=driver->createTableConstantNode((yystack_[1].value.expression));}
#line 967 "tqlparse.tab.cc"
    break;

  case 66: // postfixOperator: OB fieldSpecifierList CB
#line 221 "tqlparse.y"
                                      {(yylhs.value.postfixOperator)=driver->createPostfixOpNode((yystack_[1].value.fieldSpecifierList));}
#line 973 "tqlparse.tab.cc"
    break;

  case 67: // postfixOperator: %empty
#line 222 "tqlparse.y"
             {(yylhs.value.postfixOperator)=nullptr;}
#line 979 "tqlparse.tab.cc"
    break;

  case 68: // fieldSpecifierList: fieldSpecifier
#line 225 "tqlparse.y"
                                 {(yylhs.value.fieldSpecifierList)=driver->createFieldSpecifierList((yystack_[0].value.fieldSpecifier));}
#line 985 "tqlparse.tab.cc"
    break;

  case 69: // fieldSpecifierList: fieldSpecifierList COMMA fieldSpecifier
#line 226 "tqlparse.y"
                                                          {(yylhs.value.fieldSpecifierList)=driver->addToFieldSpecifierList((yystack_[2].value.fieldSpecifierList), (yystack_[0].value.fieldSpecifier));}
#line 991 "tqlparse.tab.cc"
    break;

  case 70: // fieldSpecifier: type identifier
#line 229 "tqlparse.y"
                                  {(yylhs.value.fieldSpecifier)=driver->createFieldSpecifier((yystack_[1].value.type), (yystack_[0].value.identifier));}
#line 997 "tqlparse.tab.cc"
    break;

  case 71: // identifier: dPrefix ID
#line 232 "tqlparse.y"
                        {(yylhs.value.identifier)=driver->createIdentifier((yystack_[1].value.dPrefix), (yystack_[0].value.ID));}
#line 1003 "tqlparse.tab.cc"
    break;

  case 72: // identifier: ID
#line 233 "tqlparse.y"
                {(yylhs.value.identifier)=driver->createIdentifier((yystack_[0].value.ID));}
#line 1009 "tqlparse.tab.cc"
    break;

  case 73: // dPrefix: DPREF DOT
#line 236 "tqlparse.y"
                  {(yylhs.value.dPrefix)=(yystack_[1].value.DPREF);}
#line 1015 "tqlparse.tab.cc"
    break;


#line 1019 "tqlparse.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        std::string msg = YY_("syntax error");
        error (YY_MOVE (msg));
      }


    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;


      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  MyParserBase::error (const syntax_error& yyexc)
  {
    error (yyexc.what ());
  }

#if YYDEBUG || 0
  const char *
  MyParserBase::symbol_name (symbol_kind_type yysymbol)
  {
    return yytname_[yysymbol];
  }
#endif // #if YYDEBUG || 0









  const signed char MyParserBase::yypact_ninf_ = -50;

  const signed char MyParserBase::yytable_ninf_ = -1;

  const short
  MyParserBase::yypact_[] =
  {
      84,     2,   -50,   123,    -3,   123,     3,    -6,    21,    48,
     -50,   -50,   -50,   -50,   -50,    22,    57,    84,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -24,    55,    32,    47,    89,
      40,   -50,   141,   -50,    68,   -50,    50,   -50,    44,   -10,
     123,   -18,   123,    64,   -13,   -50,   123,   109,   -50,   -50,
     -50,   123,   -50,   123,   -50,   -50,   123,   -50,   -50,   -50,
     -50,   -50,   -50,   123,   -50,   -50,   123,   -50,   -50,   -50,
     123,   -50,    52,   -50,   -50,   -50,   -50,     4,   -50,    23,
     123,    -6,   -50,     6,   -50,    46,    55,    32,    47,    89,
      40,   -50,   -50,   -50,   -50,   -23,    13,   -50,    84,    84,
      32,   -50,   -50,   -50,   -50,   -50,   -50,    52,    62,   -50,
     -50,    84,   -50,   -50
  };

  const signed char
  MyParserBase::yydefact_[] =
  {
       3,     0,    54,     0,     0,     0,     0,     0,     0,    72,
      63,    60,    55,    61,    62,     0,     0,     2,     4,     6,
       7,    11,     8,     9,    10,     0,    27,    29,    31,    35,
      43,    47,     0,    53,    67,    57,     0,    17,     0,     0,
       0,     0,     0,     0,     0,    19,     0,     0,    73,     1,
       5,     0,    23,     0,    33,    34,     0,    39,    40,    41,
      42,    37,    38,     0,    45,    46,     0,    49,    50,    51,
       0,    52,     0,    56,    71,    16,    64,     0,    22,     0,
       0,     0,    18,     0,    59,     0,    28,    30,    32,    36,
      44,    48,    24,    25,    26,     0,     0,    68,     0,     0,
      21,    20,    65,    58,    72,    70,    66,     0,    14,    15,
      69,     0,    12,    13
  };

  const signed char
  MyParserBase::yypgoto_[] =
  {
     -50,   -50,    90,   -17,   -50,   -50,   -50,   -50,   -50,   -50,
      12,   -50,   -50,   -50,    -2,    49,   -49,   -50,    42,   -50,
      36,   -50,    35,   -50,    33,   -50,    70,   -50,   -50,   -50,
      -1,     9,   -50
  };

  const signed char
  MyParserBase::yydefgoto_[] =
  {
       0,    16,    17,    18,    19,   112,    20,    21,    22,    44,
      45,    23,    24,    95,    25,    26,    27,    56,    28,    63,
      29,    66,    30,    70,    31,    32,    33,    34,    73,    96,
      97,    35,    36
  };

  const signed char
  MyParserBase::yytable_[] =
  {
      50,    39,    76,    41,    87,     1,    37,   104,    40,    51,
       2,    52,   102,     3,    42,    51,    98,    78,    15,   106,
      81,    50,    82,    51,    43,     4,    46,     5,     6,     7,
       8,   100,     9,    10,    11,    99,    12,    51,    77,    51,
      79,    13,    14,    15,    83,    85,   107,     1,    75,    67,
      68,    48,     2,    54,    55,     3,    51,    49,   103,    47,
      69,    57,    58,    59,    60,    61,    62,     4,    53,     5,
       6,     7,     8,    72,     9,    10,    11,    80,    12,    51,
      74,   108,   109,    13,    14,    15,   111,     1,    92,    93,
      94,    38,     2,   101,   113,     3,    64,    65,    88,    89,
      86,    90,    71,    91,   105,     0,   110,     4,     0,     5,
       6,     7,     8,     0,     9,    10,    11,     2,    12,     0,
       3,    84,     0,    13,    14,    15,     0,     0,     0,     0,
       0,     2,     0,     0,     3,     0,     0,     8,     0,     9,
      10,    11,     0,    12,     0,     0,     0,     0,    13,    14,
      15,     8,     3,     9,    10,    11,     0,    12,     0,     0,
       0,     0,    13,    14,    15,     0,     0,     0,     0,     8,
       0,     9,    10,    11,     0,     0,     0,     0,     0,     0,
      13,    14,    15
  };

  const signed char
  MyParserBase::yycheck_[] =
  {
      17,     3,    12,     5,    53,     3,     4,    30,    11,    33,
       8,    35,     6,    11,    11,    33,    12,    35,    41,     6,
      33,    38,    35,    33,    30,    23,     5,    25,    26,    27,
      28,    80,    30,    31,    32,    12,    34,    33,    40,    33,
      42,    39,    40,    41,    46,    47,    33,     3,     4,     9,
      10,    29,     8,    21,    22,    11,    33,     0,    12,    11,
      20,    14,    15,    16,    17,    18,    19,    23,    13,    25,
      26,    27,    28,     5,    30,    31,    32,    13,    34,    33,
      30,    98,    99,    39,    40,    41,    24,     3,    36,    37,
      38,     1,     8,    81,   111,    11,     7,     8,    56,    63,
      51,    66,    32,    70,    95,    -1,   107,    23,    -1,    25,
      26,    27,    28,    -1,    30,    31,    32,     8,    34,    -1,
      11,    12,    -1,    39,    40,    41,    -1,    -1,    -1,    -1,
      -1,     8,    -1,    -1,    11,    -1,    -1,    28,    -1,    30,
      31,    32,    -1,    34,    -1,    -1,    -1,    -1,    39,    40,
      41,    28,    11,    30,    31,    32,    -1,    34,    -1,    -1,
      -1,    -1,    39,    40,    41,    -1,    -1,    -1,    -1,    28,
      -1,    30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,
      39,    40,    41
  };

  const signed char
  MyParserBase::yystos_[] =
  {
       0,     3,     8,    11,    23,    25,    26,    27,    28,    30,
      31,    32,    34,    39,    40,    41,    43,    44,    45,    46,
      48,    49,    50,    53,    54,    56,    57,    58,    60,    62,
      64,    66,    67,    68,    69,    73,    74,     4,    44,    56,
      11,    56,    11,    30,    51,    52,     5,    11,    29,     0,
      45,    33,    35,    13,    21,    22,    59,    14,    15,    16,
      17,    18,    19,    61,     7,     8,    63,     9,    10,    20,
      65,    68,     5,    70,    30,     4,    12,    56,    35,    56,
      13,    33,    35,    56,    12,    56,    57,    58,    60,    62,
      64,    66,    36,    37,    38,    55,    71,    72,    12,    12,
      58,    52,     6,    12,    30,    73,     6,    33,    45,    45,
      72,    24,    47,    45
  };

  const signed char
  MyParserBase::yyr1_[] =
  {
       0,    42,    43,    43,    44,    44,    45,    45,    45,    45,
      45,    45,    46,    47,    47,    48,    49,    49,    50,    51,
      51,    52,    53,    54,    55,    55,    55,    56,    56,    57,
      57,    58,    58,    59,    59,    60,    60,    61,    61,    61,
      61,    61,    61,    62,    62,    63,    63,    64,    64,    65,
      65,    65,    66,    66,    67,    67,    68,    69,    69,    69,
      69,    69,    69,    69,    69,    69,    70,    70,    71,    71,
      72,    73,    73,    74
  };

  const signed char
  MyParserBase::yyr2_[] =
  {
       0,     2,     1,     0,     1,     2,     1,     1,     1,     1,
       1,     1,     6,     2,     0,     5,     3,     2,     3,     1,
       3,     3,     3,     2,     1,     1,     1,     1,     3,     1,
       3,     1,     3,     1,     1,     1,     3,     1,     1,     1,
       1,     1,     1,     1,     3,     1,     1,     1,     3,     1,
       1,     1,     2,     1,     1,     1,     2,     1,     4,     3,
       1,     1,     1,     1,     3,     4,     3,     0,     1,     3,
       2,     2,     1,     2
  };


#if YYDEBUG
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a YYNTOKENS, nonterminals.
  const char*
  const MyParserBase::yytname_[] =
  {
  "\"end of file\"", "error", "\"invalid token\"", "SOB", "EOB", "OB",
  "CB", "PLUS", "MINUS", "MUL", "DIV", "LP", "RP", "ASSIGN", "LT", "LTE",
  "GT", "GTE", "EQ", "NEQ", "MAT", "BAND", "BOR", "IF", "ELSE", "APPEND",
  "WHILE", "LET", "AT", "DOT", "ID", "STR", "NUM", "COMMA", "NOT",
  "SEMICOLON", "STRINGTYPE", "NUMBERTYPE", "BOOLTYPE", "TRUE", "FALSE",
  "DPREF", "$accept", "tql", "statementList", "statement", "ifStatement",
  "elsePart", "whileStatement", "compoundStatement", "letStatement",
  "varDefList", "varDef", "appendStatement", "evaluationStatement", "type",
  "expression", "commaOperand", "assignSide", "booleanOp",
  "booleanOperand", "logicalOp", "logicalOperand", "termOp", "term",
  "factorOp", "factor", "unaryOperator", "unaryOperand",
  "unaryOperandBase", "postfixOperator", "fieldSpecifierList",
  "fieldSpecifier", "identifier", "dPrefix", YY_NULLPTR
  };
#endif


#if YYDEBUG
  const unsigned char
  MyParserBase::yyrline_[] =
  {
       0,   104,   104,   105,   108,   109,   112,   113,   114,   115,
     116,   117,   120,   122,   123,   126,   129,   130,   133,   136,
     137,   139,   142,   145,   148,   149,   150,   153,   154,   157,
     158,   161,   162,   165,   166,   169,   170,   173,   174,   175,
     176,   177,   178,   181,   182,   185,   186,   189,   190,   193,
     194,   195,   198,   199,   202,   203,   206,   209,   210,   211,
     212,   213,   214,   215,   216,   217,   221,   222,   225,   226,
     229,   232,   233,   236
  };

  void
  MyParserBase::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  MyParserBase::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG

  MyParserBase::symbol_kind_type
  MyParserBase::yytranslate_ (int t) YY_NOEXCEPT
  {
    // YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to
    // TOKEN-NUM as returned by yylex.
    static
    const signed char
    translate_table[] =
    {
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41
    };
    // Last valid token kind.
    const int code_max = 296;

    if (t <= 0)
      return symbol_kind::S_YYEOF;
    else if (t <= code_max)
      return static_cast <symbol_kind_type> (translate_table[t]);
    else
      return symbol_kind::S_YYUNDEF;
  }

} // yy
#line 1472 "tqlparse.tab.cc"

#line 237 "tqlparse.y"
